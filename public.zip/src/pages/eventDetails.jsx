import { useEffect, useState, useContext } from "react"
import { useParams } from "react-router-dom"
import { userRoleContext } from "@/context/userRoleContextProvider"
import { Button } from "@/components/ui/button"

const EventDetailsPage = () => {
  const { id } = useParams()
  const { role } = useContext(userRoleContext)

  const isOrganizer = role === "organizer"

  const [event, setEvent] = useState(null)
  const [loading, setLoading] = useState(true)

  // 🔌 fetch event by id
  useEffect(() => {
    const fetchEvent = async () => {
      try {
        const res = await fetch(`http://localhost:3000/events/${id}`)
        const data = await res.json()
        setEvent(data)
      } catch (err) {
        console.error("Failed to fetch event:", err)
      } finally {
        setLoading(false)
      }
    }

    fetchEvent()
  }, [id])

  const handleEdit = () => alert("Edit event")
  const handleDelete = () => alert("Delete event")

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-gray-400">
        Loading event...
      </div>
    )
  }

  if (!event) {
    return (
      <div className="min-h-screen flex items-center justify-center text-red-400">
        Event not found
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-slate-950 to-black text-white p-6">
   <div className="absolute inset-0 bg-gradient-to-br from-black via-slate-950 to-black" />

      <div className="absolute top-[-100px] left-[-100px] w-[400px] h-[400px] bg-blue-500/20 blur-3xl rounded-full" />
      <div className="absolute bottom-[-120px] right-[-120px] w-[400px] h-[400px] bg-purple-500/20 blur-3xl rounded-full" />

      <div className="relative max-w-4xl mx-auto">

        {/* Image */}
        <div className="rounded-xl overflow-hidden mb-6 shadow-lg">
          <img
            src={
              event.image ||
              "https://images.unsplash.com/photo-1515169067868-5387ec356754?q=80&w=1200"
            }
            alt={event.title}
            className="w-full h-[300px] object-cover"
          />
        </div>

        {/* Title */}
        <h1 className="text-4xl font-bold mb-2">{event.title}</h1>

        {/* Meta */}
        <div className="text-gray-400 mb-4 flex gap-4 flex-wrap">
          <span>📅 {event.date}</span>
          <span>⏰ {event.time}</span>
          <span>📍 {event.location}</span>
        </div>

        {/* Description */}
        <p className="text-gray-300 mb-6">{event.description}</p>

        {/* Extra info */}
        <div className="bg-white/5 border border-white/10 rounded-xl p-4 mb-6">
          <p>💰 Price: <span className="text-white">${event.price}</span></p>
          <p>🎟️ Available Tickets: {event.availableTickets}</p>
          <p>👥 Capacity: {event.capacity}</p>
          <p>🏷️ Category: {event.category}</p>
        </div>

        {/* Actions */}
        <div className="flex gap-3">

          {/* Organizer actions */}
          {isOrganizer && (
            <>
              <Button onClick={handleEdit} variant="secondary">
                Edit Event
              </Button>

              <Button onClick={handleDelete} variant="destructive">
                Delete Event
              </Button>
            </>
          )}

          {/* Attendee (optional view-only actions) */}
          {!isOrganizer && (
            <Button>
              Book Ticket
            </Button>
          )}

        </div>
          </div>
          </div>

   
  )
}

export default EventDetailsPage