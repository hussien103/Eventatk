import { useContext, useState, useEffect } from "react"
import { userRoleContext } from "@/context/userRoleContextProvider"
import EventCard from "@/components/EventCard"
import { Button } from "@/components/ui/button"
import CreateEventDialog from "@/components/dialogs/createEventDialog"
import UpdateEventDialog from "@/components/dialogs/updateEventDialog"

const EventsPage = () => {
  const { role } = useContext(userRoleContext)
  const isOrganizer = role === "organizer"

  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(true)

  const [openCreate, setOpenCreate] = useState(false)
  const [openEdit, setOpenEdit] = useState(false)
  const [selectedEvent, setSelectedEvent] = useState(null)
  // 🔌 Fetch events from API
  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const res = await fetch("http://localhost:3000/events")
        const data = await res.json()
        setEvents(data)
      } catch (err) {
        console.error("Failed to fetch events:", err)
      } finally {
        setLoading(false)
      }
    }

    fetchEvents()
  }, [])

  // UI actions (mock for now)
    const handleAdd = () => setOpenCreate(true)
    const handleEdit = (event) => {
         setSelectedEvent(event)
        setOpenEdit(true)
    }
    const handleUpdated = (updatedEvent) => {
        setEvents((prev) =>
            prev.map((e) => (e.id === updatedEvent.id ? updatedEvent : e))
        )
    }
      const handleCreated = (newEvent) => { //redux better sharred resources
    setEvents((prev) => [...prev, newEvent])
  }

//   }
  const handleDelete = async (event) => {

        const res = await fetch(`http://localhost:3000/events/${event.id}`,
            {
                method:"DELETE"
            }
        )
        if(res.ok){
           setEvents((oldEvents)=>{
            return oldEvents.filter((oldEvent)=>oldEvent.id!==event.id)
            })
        }

  }
  const handleView = (event) => alert("View " + event.title)
  const handlePay = (event) => alert("Pay for " + event.title)

  return (
    <div className="relative min-h-screen text-white overflow-hidden">

      <div className="absolute inset-0 bg-gradient-to-br from-black via-slate-950 to-black" />

      <div className="relative p-6 max-w-6xl mx-auto">

        {/* Header */}
        <div className="flex justify-between items-center mb-10">
          <div>
            <h1 className="text-4xl font-bold">Events</h1>
            <p className="text-gray-400 text-sm mt-1">
              Discover and manage events
            </p>
          </div>

          {isOrganizer && (
            <Button onClick={handleAdd} className="bg-blue-600 text-white hover:bg-blue-700">
              + Create Event
            </Button>
          )}
        </div>

        {/* Content */}
        {loading ? (
          <p className="text-gray-400">Loading events...</p>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {events.map((event) => (
              <EventCard
                key={event.id}
                event={event}
                role={role}
                onEdit={handleEdit}
                onDelete={handleDelete}
                onView={handleView}
                onPay={handlePay}
              />
            ))}
          </div>
        )}

      </div>

      {/* Dialog */}
      <CreateEventDialog
        open={openCreate}
        onClose={() => setOpenCreate(false)}
        onCreated={handleCreated}
      />
     <UpdateEventDialog
        open={openEdit}
        onClose={() => setOpenEdit(false)}
        event={selectedEvent}
        onUpdated={handleUpdated}
/>
    </div>
  )
}

export default EventsPage