const Register = () => {
  return (
    <div className="container mx-auto px-4 py-20">
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-center">Login</h1>
        <div className="bg-card p-6 rounded-lg border">
          <p className="text-center text-muted-foreground">
            Login form coming soon...
          </p>
        </div>
      </div>
    </div>
  )
}

export default Register