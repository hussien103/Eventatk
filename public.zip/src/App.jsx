import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Layout from './pages/layout'
import LandingPage from './pages/landing'
import Login from './pages/login'
import Register from './pages/register'
import { ThemeProvider } from './components/ui/theme-provider'
import UserRoleContextProvider from './context/userRoleContextProvider'
import EventsPage from './pages/events'
import EventDetailsPage from './pages/eventDetails'

const OrganizerDashboard = () => <div className="container mx-auto p-8">Organizer Dashboard</div>
const PaymentDashboard = () => <div className="container mx-auto p-8">Payment Dashboard</div>
const MyEvents = () => <div className="container mx-auto p-8">My Events</div>
const MyTickets = () => <div className="container mx-auto p-8">My Tickets</div>
const AttendeeEvents = () => <div className="container mx-auto p-8">My Events (Attendee)</div>

function App() {
  return (
    <ThemeProvider>
     <UserRoleContextProvider>
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<LandingPage />} />
          <Route path="login" element={<Login />} />
          <Route path="register" element={<Register />} />
          <Route path="events" element={<EventsPage />} />
          <Route path="events/:id" element={<EventDetailsPage />} />

          {/* Organizer Routes */}
          <Route path="organizer/dashboard" element={<OrganizerDashboard />} />
          <Route path="organizer/events" element={<MyEvents />} />
          <Route path="organizer/payments" element={<PaymentDashboard />} />
          <Route path="organizer/attendees" element={<div>Attendees List</div>} />
          
          {/* Attendee Routes */}
          <Route path="attendee/tickets" element={<MyTickets />} />
          <Route path="attendee/events" element={<AttendeeEvents />} />
        </Route>
      </Routes>
    </Router>
    </UserRoleContextProvider> 
    </ThemeProvider>
  )
}

export default App