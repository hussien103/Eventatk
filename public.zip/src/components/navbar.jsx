import { useState, useEffect, useContext } from 'react'
import { Link, useLocation } from 'react-router-dom'
import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuList,
} from '@/components/ui/navigation-menu'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { Badge } from '@/components/ui/badge'
import {
  Calendar,
  Ticket,
  LayoutDashboard,
  CreditCard,
  Home,
  Menu,
  LogOut,
  User,
  Settings,
  PlusCircle,
  Bell,
  BarChart3,
} from 'lucide-react'
import { userRoleContext } from '@/context/userRoleContextProvider'

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const location = useLocation()
  const {role} = useContext(userRoleContext)
  const [user, setUser] = useState({
    role: role, // change to "attendee"
    name: 'John Doe',
  })

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // 🔥 CLEAN NAV STRUCTURE
  const getNavLinks = () => {
    if (!user) {
      return [
        { name: 'Home', path: '/'},
        { name: 'Browse Events', path: '/events'  },
      ]
    }

    if (user.role === 'organizer') {
      return [
        { name: 'Dashboard', path: '/dashboard'  },
        { name: 'My Events', path: '/events' },
      ]
    }

    // attendee
    return [
      { name: 'Home', path: '/',  },
      { name: 'Browse Events', path: '/events', },
      { name: 'My Tickets', path: '/tickets', },
    ]
  }

  const navLinks = getNavLinks()
  const isActive = (path) => location.pathname === path

  const handleLogout = () => setUser(null)

  return (
<nav
  className={`fixed top-0 w-full z-50 transition-all duration-300 ${
    isScrolled
      ? "bg-black/40 backdrop-blur-md border-b border-white/10"
      : "bg-transparent"
  }`}
>
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">


        <Link to="/" className="flex items-center gap-2">
          <img src="tent-png-35660.png" width={40} height={35}/>

          <span className="font-bold text-xl text-blue-600">
            Eventatk
          </span>
        </Link>

        {/* DESKTOP NAV */}
        <div className="hidden md:flex">
          <NavigationMenu>
            <NavigationMenuList className="flex gap-2">
              {navLinks.map((link) => (
                <NavigationMenuItem key={link.path}>
                  <Link
                    to={link.path}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm transition ${
                      isActive(link.path)
                        ? 'bg-sky-500/10 text-white'
                        : 'hover:bg-accent'
                    }`}
                  >
                    {link.name}
                  </Link>
                </NavigationMenuItem>
              ))}
            </NavigationMenuList>
          </NavigationMenu>
        </div>

        <div className="flex items-center gap-3">

          {!user ? (
            <div className="hidden md:flex gap-2">
              <Button variant="ghost">Login</Button>
              <Button className="bg-blue-600 text-white">
                Sign Up <PlusCircle className="w-4 h-4 ml-2" />
              </Button>
            </div>
          ) : (
            <div className="hidden md:flex items-center gap-3">

              <Button variant="ghost" size="icon">
                <Bell className="w-5 h-5" />
                <Badge className="absolute -top-1 -right-1 bg-red-500">
                  2
                </Badge>
              </Button>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Avatar className="cursor-pointer">
                    <AvatarFallback>{user.name[0]}</AvatarFallback>
                  </Avatar>
                </DropdownMenuTrigger>

                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>
                    {user.name}
                  </DropdownMenuLabel>

                  <DropdownMenuSeparator />

                  <DropdownMenuItem>
                    <User className="w-4 h-4 mr-2" />
                    Profile
                  </DropdownMenuItem>

                  <DropdownMenuItem>
                    <Settings className="w-4 h-4 mr-2" />
                    Settings
                  </DropdownMenuItem>

                  <DropdownMenuSeparator />

                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          )}

          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu />
              </Button>
            </SheetTrigger>

            <SheetContent side="right">
              <div className="flex flex-col gap-3 mt-10">
                {navLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="flex gap-2 p-2 rounded hover:bg-accent"
                  >
                    {link.name}
                  </Link>
                ))}
              </div>
            </SheetContent>
          </Sheet>

        </div>
      </div>
    </nav>
  )
}

export default Navbar