import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useNavigate } from "react-router-dom"

const EventCard = ({ event, role, onEdit, onDelete, onView, onPay }) => {
  const isOrganizer = role === "organizer"
  const navigate = useNavigate()
  const handleCardClick = () =>{
        navigate(`${event.id}`)
  }  
  return (
    <Card onClick={handleCardClick} className="bg-white/5 border-white/10 backdrop-blur text-white overflow-hidden hover:scale-[1.02] transition-transform duration-200">

      {/* Image section */}
      <div className="h-40 w-full overflow-hidden">
        <img
          src={
            event.image ||
            "https://images.unsplash.com/photo-1515169067868-5387ec356754?q=80&w=1200"
          }
          alt={event.title}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Content */}
      <CardHeader className="pb-2">
        <CardTitle className="flex justify-between items-center text-lg">
          {event.title}
          <span className="text-xs text-gray-300">{event.date}</span>
        </CardTitle>
      </CardHeader>

      <CardContent>
        <p className="text-gray-300 text-sm mb-3 line-clamp-2">
          {event.description}
        </p>

        <p className="text-sm text-gray-400 mb-4">
          💰 Price: <span className="text-white font-semibold">${event.price}</span>
        </p>

        <div className="flex gap-2 flex-wrap">

          {/* Attendee actions */}
          {!isOrganizer && (
            <>
              <Button onClick={() => handleCardClick} variant="secondary">
                Details
              </Button>

              <Button onClick={() => onPay(event)}>
                Pay Ticket
              </Button>
            </>
          )}

          {/* Organizer actions */}
          {isOrganizer && (
            <>
            <Button
                onClick={(e) => {
                    e.stopPropagation()
                    onEdit(event)
                }}
                variant="secondary"
                >
                Edit
                </Button>

                <Button
                    onClick={(e) => {
                        e.stopPropagation()
                        onDelete(event)
                    }}
                    variant="destructive"
                    >
                    Delete
                </Button>
            </>
          )}

        </div>
      </CardContent>
    </Card>
  )
}

export default EventCard