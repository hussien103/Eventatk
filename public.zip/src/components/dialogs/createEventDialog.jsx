import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

const CreateEventDialog = ({ open, onClose, onCreated }) => {
  const [form, setForm] = useState({
    title: "",
    description: "",
    date: "",
    time: "",
    location: "",
    price: "",
    capacity: "",
    category: "",
    image: "",
  })

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleSubmit = async () => {
    try {
      const res = await fetch("http://localhost:3000/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          price: Number(form.price),
          capacity: Number(form.capacity),
          availableTickets: Number(form.capacity),
        }),
      })

      const data = await res.json()
      onCreated(data)
      onClose()
    } catch (err) {
      console.error("Failed to create event:", err)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-black text-white border-white/10 max-w-2xl">
        
        <DialogHeader>
          <DialogTitle>Create Event</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-3 mt-4">

          <Input name="title" placeholder="Title" onChange={handleChange} />
          <Input name="date" type="date" onChange={handleChange} />

          <Input name="time" type="time" onChange={handleChange} />
          <Input name="location" placeholder="Location" onChange={handleChange} />

          <Input name="price" type="number" placeholder="Price" onChange={handleChange} />
          <Input name="capacity" type="number" placeholder="Capacity" onChange={handleChange} />

          <Input name="category" placeholder="Category" onChange={handleChange} className="col-span-2" />
          <Input name="image" placeholder="Image URL" onChange={handleChange} className="col-span-2" />

          <Textarea
            name="description"
            placeholder="Description"
            onChange={handleChange}
            className="col-span-2"
          />

        </div>

        <div className="flex justify-end gap-2 mt-4">
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>

          <Button onClick={handleSubmit}>
            Create
          </Button>
        </div>

      </DialogContent>
    </Dialog>
  )
}

export default CreateEventDialog