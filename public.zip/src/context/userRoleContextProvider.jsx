import { createContext, useState } from "react";

export const userRoleContext = createContext();

export default function UserRoleContextProvider({ children }) {
  const [role] = useState("organizer");

  return (
    <userRoleContext.Provider value={{ role }}>
      {children}
    </userRoleContext.Provider>
  );
}